(1) copy your assignment2.cpp source file here.

(2) chmod +x compile_files.sh

(3) ./compile_files.sh (if unsuccessfull, then try ./compile_files_no_werror.sh)

(4) calico BLG252E_OOP19_HW2_Evaluation_Tests.t

